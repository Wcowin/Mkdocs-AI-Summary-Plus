---
hide:
#   - navigation # 显示右
  - toc #显示左
  - footer
#   - feedback
# comments: false
# icon: octicons/home-fill-24
hide_reading_time: true
ai_summary: false  # 强制启用AI摘要
---

# MyBlog
<div class="grid cards" markdown>

-   :material-clock-fast:{ .lg .middle } __What is Blog?__

    ---
    **博客，仅音译，英文名为Blogger，为Web Log的混成词。** 
    **其正式名称为网络日记；又音译为部落格或部落阁等，是社会媒体网络的一部分。是使用特定的软件，在网络上出版、发表和张贴个人文章的人，或者是一种通常由个人管理、不定期张贴新的文章的网站**
</div>


***


<!-- <style>

.md-grid {
  max-width: 1100px;
}
</style> -->